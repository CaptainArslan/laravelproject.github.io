<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use Illuminate\Support\Facades\DB;


class UserModel extends Model
{
    use HasFactory;
    function get_db_data()
    {
        $users = DB::select('select * from tbl_userdata');
        return $users;
    }

    function get_edit_data(){
        $user =  DB::select('select * from tbl_userdata where ');
        return $user;
    }
}
