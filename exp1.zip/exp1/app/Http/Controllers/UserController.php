<?php

namespace App\Http\Controllers;

use App\Models\UserModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class UserController extends Controller
{
    public function db_data(Request $request){
        $obj = new UserModel();
        $db_user = $obj -> get_db_data();
        return view('index',[ 'user' => $db_user ]);
    }
}
